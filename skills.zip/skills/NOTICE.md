# NOTICE — extracted office skills

This directory contains four skill bundles extracted from **ZCode**, Z.ai's coding-agent harness,
and adapted so that they no longer depend on that host.

## Upstream

| Item | Value |
|---|---|
| Repository | <https://github.com/zai-org/ZCode> |
| Revision | `c5904686` — `chore: sync ZCode source v3.18.1` (2026-11-12) |
| License | Apache License 2.0, `Copyright (c) 2026 Z.ai` |
| Upstream location | `apps/zcode-cli/packages/{documents,pdf,presentations,spreadsheets}-plugin/skills/*` |

Each extracted bundle keeps its own `LICENSE.txt` (identical Apache-2.0 text, MD5
`7CB1CC2D17C44CCC0FB9E119E39EC8F0`). The Apache-2.0 license text is available at
<https://www.apache.org/licenses/LICENSE-2.0>.

## Mapping

| This copy | Upstream path | Upstream skill name |
|---|---|---|
| `lb-docx/` | `documents-plugin/skills/docx` | `docx` |
| `lb-xlsx/` | `spreadsheets-plugin/skills/xlsx` | `xlsx` |
| `lb-pptx/` | `presentations-plugin/skills/pptx` | `pptx` |
| `lb-pdf/` | `pdf-plugin/skills/pdf` | `pdf` |
| `lb-office/` | — (new) | — |

## Modifications (Apache-2.0 §4(b))

Every modified file is listed in `../MIGRATION.md`. In summary:

1. **Identity** — front-matter `name` prefixed with `lb-` (host skill names must be lowercase
   kebab-case); `license` corrected from `Proprietary` to `Apache-2.0`, matching `LICENSE.txt`;
   `metadata.upstream` / `metadata.extracted` added.
2. **Citations** — the host-specific `::zcode-file-citation{...}` directive (22 occurrences, all in
   the four `SKILL.md` files) was replaced with plain Markdown links plus a host note.
3. **Runtime resolution** — an "Environment (read this first)" section was added to each `SKILL.md`;
   installer scripts (`setup.sh`, `env_setup/setup_{mac_linux,sh,windows.ps1}`) now stop in
   check-only mode unless `LB_ENV_INSTALL=1`; `npm install -g pptxgenjs` became a local install.
4. **Degraded mode** — a dependency/degradation table was appended to each `SKILL.md`.

## Not carried over

- `skills/*-viewer/` — depend on ZCode's `office-runtime` MCP panel server (`${ZCODE_PLUGIN_ROOT}`),
  which has no counterpart outside that host.
- `agents/visual-judge.md` — a ZCode sub-agent definition.
- `.zcode-plugin/plugin.json` — host plugin manifest.

## Trademarks

"ZCode" and "Z.ai" are trademarks of their owner. This copy is an independent extraction and is not
endorsed by or affiliated with Z.ai. Skill instructions remain the upstream author's work.
