# Environment for the `lb-*` office skills

These skills are host-neutral. They need a Python interpreter, Node.js, and — only when a format
conversion or a visual check is required — LibreOffice. Nothing is installed into a host application.

## 1. Resolve the interpreters (do this once per session)

**Python** — first match wins:

1. `$OFFICE_PYTHON` (or `%OFFICE_PYTHON%`) if set and executable;
2. project virtual environment: `<cwd>/.venv/Scripts/python.exe` on Windows, `<cwd>/.venv/bin/python`
   elsewhere;
3. `python3`, then `python`, from `PATH`.

```powershell
# PowerShell
$PY = if ($env:OFFICE_PYTHON) { $env:OFFICE_PYTHON }
      elseif (Test-Path '.venv\Scripts\python.exe') { '.venv\Scripts\python.exe' }
      else { 'python' }
```

```bash
# bash
PY="${OFFICE_PYTHON:-}"
[ -z "$PY" ] && [ -x .venv/bin/python ] && PY=.venv/bin/python
[ -z "$PY" ] && PY=$(command -v python3 || command -v python)
```

**Node** — npm packages must resolve from the working directory. If a generated script runs from a
different directory, export the local `node_modules`:

```powershell
$env:NODE_PATH = (Resolve-Path '.\node_modules').Path   # after `npm install <pkg>`
```

## 2. Dependencies per skill

| Skill | Python packages | Node packages | External |
|---|---|---|---|
| `lb-docx` | `defusedxml` (postcheck) | `docx` | LibreOffice (convert / visual check) |
| `lb-xlsx` | `openpyxl` | — | LibreOffice (recalc / export) |
| `lb-pptx` | `python-pptx` (optional) | `pptxgenjs` | LibreOffice, a PDF rasterizer |
| `lb-pdf` | `reportlab`, `pdfplumber`, `pikepdf`, `pdf2image`, `PyMuPDF` | — | poppler (`pdftoppm`), LaTeX (`tectonic`) or `playwright` — all optional per pipeline |

Notes:

- `PyMuPDF` (`import fitz`) is the universal fallback rasterizer: it replaces `pdftoppm` and can
  substitute for `pdf2image`.
- `pdf2image` still needs poppler at runtime; `PyMuPDF` does not.
- LaTeX (`tectonic`) and `playwright` gate only the PDF skill's LaTeX / HTML engines; the
  reportlab-based pipeline works without them.

## 3. Provisioning (project-local, never global)

```powershell
python -m venv --system-site-packages .venv
.\.venv\Scripts\python.exe -m pip install defusedxml reportlab pdfplumber pikepdf pdf2image
npm install docx pptxgenjs            # in the working directory, no -g
```

`--system-site-packages` lets the venv reuse an already-installed `python-docx`, `openpyxl`,
`python-pptx`, `PyMuPDF`, `pypdf`, `lxml`, `Pillow`. Drop the flag for full isolation.

## 4. Verifying

```powershell
& $PY -c "import importlib.util as u;mods=['defusedxml','reportlab','pdfplumber','pikepdf','pdf2image','docx','openpyxl','pptx','fitz'];print('\n'.join(('OK   ' if u.find_spec(m) else 'MISS ')+m for m in mods))"
Test-Path .\node_modules\docx\package.json
& 'C:\Program Files\LibreOffice\program\soffice.exe' --version
```

## 5. Installer scripts are inert by default

`setup.sh`, `env_setup/setup_mac_linux.sh` and `env_setup/setup_windows.ps1` now print a notice and
exit 0 unless `LB_ENV_INSTALL=1` is set. They never install into a host application, and even with
the override they only install Python/Node packages and (at most) suggest LibreOffice.

## 6. Degraded mode

Each `SKILL.md` ends with a `Degraded mode` table stating what fails when a dependency is absent and
what to do instead. The rule in every case: **report the gap, do not silently substitute a different
program** (Word, WPS, Pages, Keynote) without the user's approval.

## 7. Windows notes (verified on this machine, 2026-11-13)

These were all hit during the extraction experiments; record them so the next run does not rediscover
them.

| Symptom | Cause | Fix |
|---|---|---|
| `UnicodeEncodeError: 'gbk' codec can't encode character '\U0001f4cb'` from `postcheck.py` | console code page is GBK and the script prints emoji | set `PYTHONIOENCODING=utf-8` for the run (or `chcp 65001`) |
| `Error: Cannot find module 'docx'` / `pptxgenjs` | packages are installed project-locally, not globally | set `NODE_PATH` to the directory holding `node_modules` before `node` |
| `soffice --headless --convert-to pdf` returns immediately and writes nothing | `soffice.exe` detaches on Windows | run it through `Start-Process -Wait`, e.g. `Start-Process soffice.exe -ArgumentList '--headless','--norestore','-env:UserInstallation=file:///C:/Temp/lo_x','--convert-to','pdf','--outdir',$out,$file -Wait` |
| `xlsx.py recalc` reports `success` but the saved file keeps empty `<v></v>` caches | a stale `soffice.bin` from an earlier run absorbs the request; the Basic macro never runs | kill leftover `soffice`/`soffice.bin` first, then recalculate with a LibreOffice round-trip: `soffice --convert-to xlsx` into a temp dir and replace the original |
| `xlsx.py audit` hangs for minutes | it shells out to LibreOffice with no timeout wrapper on Windows | run it with a job/`Start-Process` timeout, or skip it in favour of `validate` + `recalc` |
| `pdf_qa.py` prints `⚠️ Warnings (1):` with no body | the count includes an empty entry in this build | ignore the empty block; rely on the `Passed (n)` lines |

