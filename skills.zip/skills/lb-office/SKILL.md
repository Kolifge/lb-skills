---
name: lb-office
description: "Router for the Lb office skill family. Use when the task involves producing, editing, converting, or inspecting an Office document but the format is not yet settled, or when several formats are involved at once (Word/DOCX, Excel/XLSX, PowerPoint/PPTX, PDF). Also use when the user says 做一份文档、生成表格、做个 PPT、导出 PDF、把 Word 转成 PDF、批量整理办公文件, or asks which of these skills applies. It routes to lb-docx, lb-xlsx, lb-pptx or lb-pdf and states the shared preconditions; it does not generate files itself."
metadata:
  author: "Z.AI (extraction), lb migration"
  version: "0.1.0"
  upstream: "zai-org/ZCode@c5904686 — router written for this host-neutral extraction"
license: Apache-2.0 (see NOTICE.md)
---

# Office router

This skill decides **which** format skill to load. Load exactly one, then follow it.

## Route

| Signal | Load |
|---|---|
| `.docx`, Word, 文档, 报告, 合同, 简历, 论文, 公文, 批注/修订, doc → docx | `lb-docx` |
| `.xlsx` / `.xlsm`, Excel, 表格, 工作表, 公式, 图表, 透视表, 财务模型, 数据清洗 | `lb-xlsx` |
| `.pptx`, PowerPoint, 幻灯片, 演示文稿, 汇报, 路演, deck, slides | `lb-pptx` |
| `.pdf`, PDF 排版, 海报, 画册, 报告排版, 封面设计, PDF 合并/拆分/水印 | `lb-pdf` |

Tie-breakers:

- **Input format wins over output format.** "把这份 PDF 总结成文档" is a read task on `lb-pdf`;
  "把这些数据做成报告.docx" is `lb-docx` with data supplied by the user.
- **Two formats, one deliverable**: pick the skill of the *deliverable*, and let it call LibreOffice
  for the conversion. `Word 转 PDF` → `lb-docx` (its own conversion route), not `lb-pdf`.
- **Pure conversion with no authoring**: `docx→pdf`, `pptx→pdf`, `xlsx→pdf` are one `soffice
  --convert-to pdf` call; do it with the skill that owns the source format.
- **Several deliverables of different formats**: handle them sequentially, loading the next skill
  after the current one ships. Do not hold four SKILL.md bodies at once.
- If the user has not said, ask once — format, audience, and whether it must be editable.

## Preconditions (all four skills)

1. Resolve the interpreter and Node packages **before** the first script call — see
   [`../_shared/ENVIRONMENT.md`](../_shared/ENVIRONMENT.md). Never assume a global install.
2. Never run `setup.sh` / `env_setup/*` from these skills in install mode; they are inert unless
   `LB_ENV_INSTALL=1`.
3. Never modify the user's input file in place. Write `<stem>_updated.<ext>` next to it; copy to
   `<stem>_backup.<ext>` before any explicitly requested in-place edit.
4. Verify before delivering: run the skill's own postcheck/QA script, and render the result when the
   layout matters. State what you actually checked.
5. If a required dependency is missing, say which one and what it blocks. Do not silently substitute
   Word / WPS / Pages / Keynote.

## Boundaries

- These skills **produce** files with Python/Node libraries plus LibreOffice; they are not a native
  editor and do not provide live document panels.
- Office documents are ZIP+XML. For surgical XML edits, use the owning skill's `ooxml`-style
  references instead of ad-hoc unzip-and-edit.
